""""Welcome To File Protector"""


from cryptography.fernet import Fernet # For Encryption...
import os as self # For all.
import colorama as color # For Color
from tqdm import tqdm # Loading Bar
import time

F1 = input(
    str(
        "What File Do You Want Encrypted?: "
    )
)

data = open ("./Data/Data.txt", 'wb')
data.write(F1.encode())

def func():

    for x in tqdm(range(100), desc=color.Fore.GREEN + "Processing..."):
        time.sleep(
            0.5
        )
    with open(F1, 'rb') as File_open:
        Read_file = File_open.read()
        
    key = Fernet.generate_key()

    with open("./Key/Key.key", 'wb') as enc_key:
        enc_key.write(key)

    fernet = Fernet(key)

    Enc_file = fernet.encrypt(Read_file)

    with open(F1, 'wb') as file_open1:
        file_open1.write(Enc_file)

func()