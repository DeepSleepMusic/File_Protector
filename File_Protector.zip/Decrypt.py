from cryptography.fernet import Fernet
import time
from tqdm import tqdm
import colorama as color

def func():
    with open("./Key/Key.key", 'rb') as get_key:
        read_key = get_key.read()

    fernet = Fernet(read_key)

    with open("./Data/Data.txt", 'rb') as r1:
        rr = r1.read()

    decrypt = fernet.decrypt(rr)

    data = open("./Data/Data", 'wb')
    data.write(decrypt)
func()